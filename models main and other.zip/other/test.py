import rlgym


rlgym.make('Duel')
